TANA6X — Updated Official Artist Website

WHAT'S UPDATED
- BIG TRUCK MUSIC Listen on YouTube button points to:
  https://www.youtube.com/playlist?list=PLKAuEGstSTNjfn0IVkliNC60ZuTl4ThwZ
- T.R.A.P Listen on YouTube button points to:
  https://www.youtube.com/playlist?list=PLeU0x4bfEX2Q
- YouTube channel button points to:
  https://www.youtube.com/channel/UChV-t_q5RL1jAKH6VU0BIwQ

PREVIEW
Open index.html in a web browser.

PUBLISH / UPDATE FOR FREE WITH GITHUB PAGES
1. Open your GitHub repository for the TANA6X site.
2. Replace the existing index.html with this updated index.html.
3. Commit/save the change.
4. Your GitHub Pages website should update automatically after deployment.

NOTE
The SoundCloud button is still a search link because an exact SoundCloud profile URL was not provided.
Google indexing is not instant or guaranteed. After publishing, use Google Search Console to request indexing.
